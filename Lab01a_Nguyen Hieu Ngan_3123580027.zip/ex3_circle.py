print('Nhap ban kinh hìn tron: ')
r= float(input())
cv = 2*3.1416*r
dt=3.14*r*r
print('Chu vi hinh tron la: ',cv)
print('Dien tich hinh tron la: ',dt)